package com.example.music_service.models.data;

import com.example.music_service.R;

public class PlaylistsData {

    public static String[] playlistNames = new String[]{"Hot ", "Fresh ", "For You ", "Home ",
            "Mood ", "Sweet Chill ", "Best ", "Cool ",
            "Top 2022 ", "Top 2021 ", "Top 2020 ",
            "Relax ", "Dance ", "Repeat "};

    //public static Drawable[] playlistImages = new Drawable[] { "user_blue.png", "user_bubble_gum.png", "user_green.png", "user_purple.png", "user_red.png", "user_tropical.png" };
    public static Integer[] playlistImages = new Integer[]{R.drawable.user_blue, R.drawable.user_green, R.drawable.user_purple, R.drawable.user_red, R.drawable.user_bubble_gum, R.drawable.user_tropical};
}
