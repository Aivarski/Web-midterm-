package com.example.music_service.models.data;

import com.example.music_service.models.Playlist;

import java.util.ArrayList;

public class HomeFragmentData {

    public static ArrayList<Playlist> morningPlaylists = new ArrayList<>();
    public static ArrayList<Playlist> recommendations = new ArrayList<>();
    public static ArrayList<Playlist> popular = new ArrayList<>();

}
