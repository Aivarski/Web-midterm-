package com.example.music_service.models.data;

import com.example.music_service.models.Playlist;
import com.example.music_service.models.Song;

import java.util.ArrayList;

public class LibraryFragmentData {

    public static ArrayList<Song> bestSongs = new ArrayList<>();
    public static Playlist dailyTopSongs;
    public static ArrayList<Song> dailyTops = new ArrayList<>();

}
