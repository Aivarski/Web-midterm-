# Tune Studio
## Music Service app for Android platform (Android Studio, Java)
In this app you can create your account and organise different playlists of music based on your taste,\
you can also listen to the ones that system has created for you. Furthermore,\
you are able to control your playing queueu, remove any tracks and add new (you can add only one track or a whole playlist)

<p float="center">
  <img src="https://github.com/M1estere/Music_Service_Studio/assets/58213582/9c17ec4a-193c-4525-a7ee-5434269d6391.jpg" height="500" />
  &nbsp;&nbsp;
  <img src="https://github.com/M1estere/Music_Service_Studio/assets/58213582/7879d4fb-c613-44ff-8aa8-44a28ec2b9bc.jpg" height="500" />
  &nbsp;&nbsp;
  <img src="https://github.com/M1estere/Music_Service_Studio/assets/58213582/b77187a8-35ca-4612-bffb-ad6869936bb8.jpg" height="500" />
</p>
